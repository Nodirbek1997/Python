print("Hello World)
