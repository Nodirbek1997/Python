"""
01/01/2021

Dasturlash asoslari

#24-dars: FUNKSIYALAR SO'NGSO'Z

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""
f1 = lambda x: x * 10
print(f1(10))

f2 = lambda x, y: x * y
print(f2(5, 4))
