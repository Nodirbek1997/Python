# python-darslar
Assalom alaykum hurmatli Do'stlar, bu yerda <a href="https://python.sariq.dev">python.sariq.dev</a> sahifamizida qo'yib borilayotgan darslarga oid kodlar va dasturlarni yuklab olishingiz mumkin.
