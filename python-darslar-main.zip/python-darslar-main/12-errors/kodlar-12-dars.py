"""
25/11/2020

Dasturlash asoslari

#12-dars: Xatolar bilan ishlash

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""
# SintaxError
# print "Hello World!"
# print("Hello World!"
# print("Assalom alaykum!")

# IndentationError
# print("Hello World!")

# print("O'ngacha sanaymiz")
# for n in range(10):
# print(n+1)

# son = 50
# if son>=0:
#     print("Musbat son")
# else:
#     print("Manfiy son")

# TypeError
# son = input("Istalgan son kiriting: ")
# print(f"{son} ning kvadrati {son**2} ga teng")

# #NameError
# # prit("Hello World!")
# mevalar = ['olma','uzum','nok','anor','anjir']
# for meva in mevalar:
#     print(meva)

# ValueError

# son = int(input("Istalgan son kiriting: "))
# if son>=0:
#     print("Musbat son")
# else:
#     print("Manfiy son")

# #IndexError
# mevalar = ['olma','anor','uzum']
# print(mevalar[2])

# ZeroDivisionError
# x, y = 50, 50
# z = 250/(x-y)

# Mantiqiy xatolar
# radius = 5
# pi = 4.14
# aylana_yuzi = pi*radius**2
# print(aylana_yuzi)

# son = float(input("Istalgan son kiriting: "))
# ildiz = son**1/2
# print(f"{son} ning ildizi {ildiz} ga teng")

# mevalar = ['olma','uzum','nok','anor','anjir']
# for meva in mevalar:
#     print(meva)
#     print("Dastur tugadi")
