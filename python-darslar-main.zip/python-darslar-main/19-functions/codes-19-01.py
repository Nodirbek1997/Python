"""
16/12/2020

Dasturlash asoslari

#19-dars: FUNCTIONS (FUNKSIYALAR)

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""


def salom_ber():
    """Salom beruvchi funksiya"""
    print("Assalomu alaykum!")


salom_ber()
