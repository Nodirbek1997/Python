"""
09/01/2021

Dasturlash asoslari

"SO'Z TOPISH" O'YINI

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""
from funksiyalar import play

play()
