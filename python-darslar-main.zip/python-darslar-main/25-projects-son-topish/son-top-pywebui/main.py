from sontop import sontop, sontop_pc

sontop()
sontop_pc()
