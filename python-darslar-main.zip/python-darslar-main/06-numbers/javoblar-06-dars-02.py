"""
09/11/2020

Dasturlash asoslari

#06-dars: Sonlar

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""
# Foydalanuvchining yoshini so'rang,
# va uning tug'ilgan yilini hisoblab, konsolga chiqaring.
yosh = int(input("Yoshingiz nechida? \n>>>"))
t_yil = 2020 - yosh
print("Siz ", t_yil, " da tug'ilgansiz")
