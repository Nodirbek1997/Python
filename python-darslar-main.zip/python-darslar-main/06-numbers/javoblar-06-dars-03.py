"""
09/11/2020

Dasturlash asoslari

#06-dars: Sonlar

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""
# Foydalanuvchidan ikki son kiritshni so'rab,
# kiritilgan sonlarning yig'indisi, ayirmasi,
# ko'paytmasi va bo'linmasini chiqaruvchi dastur
a = float(input("Birinchi sonni kiriting: "))
b = float(input("Ikkinchi sonni kiriting: "))
print(f"{a}+{b}=", a + b)
print(f"{a}-{b}=", a - b)
print(f"{a}x{b}=", a * b)
print(f"{a}/{b}=", a / b)
