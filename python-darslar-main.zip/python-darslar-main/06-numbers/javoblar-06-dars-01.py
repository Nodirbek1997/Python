"""
09/11/2020

Dasturlash asoslari

#06-dars: Sonlar

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""

x = int(input("Istalgan son kiriting:\n>>>"))
print(x, " ning kvadrati ", x ** 2, " ga teng")
print(x, " ning kubi ", x ** 3, " ga teng")
