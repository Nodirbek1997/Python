"""
24/12/2020

Dasturlash asoslari

#24-dars: MODULLAR

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""
import math

x = 400
# print(math.sqrt(x))
# print(math.pow(6,2))
# print(math.pi)
print(math.log2(8))
print(math.log10(100))
