"""
21/01/2021

Dasturlash asoslari

#28-DARS. KLASSLAR

Muallif: Anvar Narzullaev

Web sahifa: https://python.sariq.dev
"""


class User:
    def __int__(self, name, username, email, birth_year):
        self.name = name
        self.uname = username
        self.mail = email
        self.year = birth_year

    def describe():
        pass

    def get_name():
        pass
